# Bus Schedule — backup generator for all Łódź stops

This package contains a GitHub Actions workflow that downloads the public MPK Łódź stop index and generates `bus_schedule_lodz_all_stops.json` using the requested URL format:

`http://rozklady.lodz.pl/Home/TimeTableReal?busStopNum=0209`

The script preserves leading zeroes and distinct stop/platform numbers. It does not guess numbers by incrementing a range. The workflow commits the generated JSON to the repository and also publishes it as a downloadable workflow artifact.

## Use on Android

1. Upload the contents of this ZIP into the root of your `bus-schedule` GitHub repository. Make sure the `.github/workflows/build-stops-backup.yml` file is included.
2. Open the repository in Chrome and select **Actions**.
3. Open **Build Łódź all-stops backup** and press **Run workflow**.
4. When the run finishes, download the artifact named `bus_schedule_lodz_all_stops` or find the JSON in the repository root.

Note: MPK's official index is the source for stop numbers. The generated URLs follow the legacy `TimeTableReal?busStopNum=` pattern, but the script cannot independently verify every legacy timetable page's current availability.
