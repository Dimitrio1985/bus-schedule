#!/usr/bin/env python3
"""Generate a JSON stop catalog from the public MPK Łódź stop index.

Each official stop number is kept as text (leading zeroes preserved) and
mapped to the requested TimeTableReal URL format.
"""
import json
import re
import urllib.request
from html.parser import HTMLParser
from pathlib import Path

SOURCE_URL = "https://mpk.lodz.pl/rozklady/przystanki.jsp"
BASE_URL = "http://rozklady.lodz.pl/Home/TimeTableReal?busStopNum="
OUT = Path("bus_schedule_lodz_all_stops.json")

class StopLinkParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.in_link = False
        self.href = ""
        self.parts = []
        self.records = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag.lower() == "a" and "stopNumber=" in attrs.get("href", ""):
            self.in_link = True
            self.href = attrs.get("href", "")
            self.parts = []

    def handle_data(self, data):
        if self.in_link:
            self.parts.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == "a" and self.in_link:
            match = re.search(r"stopNumber=(\d+)", self.href)
            label = " ".join("".join(self.parts).split())
            if match:
                code = match.group(1)
                # MPK labels usually contain the public stop name and its code.
                name = re.sub(r"\s*\(?\s*" + re.escape(code) + r"\s*\)?\s*$", "", label).strip()
                if not name:
                    name = "Przystanek " + code
                self.records.append({"name": name, "code": code})
            self.in_link = False
            self.href = ""
            self.parts = []

def main():
    request = urllib.request.Request(SOURCE_URL, headers={"User-Agent": "BusScheduleBackup/1.0"})
    with urllib.request.urlopen(request, timeout=45) as response:
        html = response.read().decode("utf-8", errors="replace")

    parser = StopLinkParser()
    parser.feed(html)

    # Preserve distinct platform codes, remove repeated links for the same code.
    by_code = {}
    for item in parser.records:
        by_code.setdefault(item["code"], item["name"])

    if not by_code:
        raise SystemExit("No stop numbers were parsed; refusing to create an empty backup.")

    stops = [
        {"name": by_code[code], "url": BASE_URL + code, "stopNum": code}
        for code in sorted(by_code, key=lambda x: (int(x), x))
    ]
    output = {"app": "bus-schedule", "v": 1, "source": SOURCE_URL,
              "district": "Łódź — wszystkie rejony", "stops": stops}
    OUT.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Created {OUT} with {len(stops)} unique official stop numbers.")

if __name__ == "__main__":
    main()
